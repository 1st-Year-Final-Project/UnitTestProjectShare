﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using ZPool.Models;
using ZPool.Services.EFService;
using ZPool.Services.Interface;

namespace xUnitTestProject
{
    public class BookingServiceTest : ServiceTest
    {
        private IBookingService _bookingService;
        private AppDbContext _context;

        // Constructor
        // A local SqLite Db is used for testing. It is created and disposed of on demand.
        public BookingServiceTest() : base(new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Filename=BookingTest.db")
            .Options)
        {
            _context = new AppDbContext(ContextOptions);
            _bookingService = new EFBookingService(_context);
        }
    }
}
