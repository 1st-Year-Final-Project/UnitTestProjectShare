﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Xunit;
using ZPool.Models;
using ZPool.Services.EFService;
using ZPool.Services.Interface;

namespace xUnitTestProject
{
    public class CarServiceTest : ServiceTest
    {
        private ICarService _carService;
        private AppDbContext _context;

        // Constructor
        // A local SqLite Db is used for testing. It is created and disposed of on demand.
        public CarServiceTest() : base(new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Filename=CarTest.db")
            .Options)
        {
            _context = new AppDbContext(ContextOptions);
            _carService = new EFCarService(_context);
        }

        [Fact]
        public void GetAllCars_Test()
        {
            // Arrange & Act
            var cars = _carService.GetCars();

            // Assert
            Assert.Equal(3, cars.Count());
            Assert.Equal("Skoda", cars.ToList()[0].Brand);
        }

        [Fact]
        public void GetCar_Test()
        {
            Car car = _carService.GetCar(1);

            Assert.Equal(1, car.CarID);
            Assert.Equal("Skoda", car.Brand);
        }

        [Fact]
        public void DeleteCar_Test()
        {
            _carService.DeleteCar(_carService.GetCar(3));

            Assert.Equal(2, _carService.GetCars().Count());
        }


    }
}
