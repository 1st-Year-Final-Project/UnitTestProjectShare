﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Xunit;
using ZPool.Models;
using ZPool.Services.EFService;
using ZPool.Services.EFService.RideService;
using ZPool.Services.Interface;

namespace xUnitTestProject
{
    public class RideServiceTest : ServiceTest
    {
        private IRideService _rideService;
        private AppDbContext _context;

        // Constructor
        // A local SqLite Db is used for testing. It is created and disposed of on demand.
        public RideServiceTest() : base(new DbContextOptionsBuilder<AppDbContext>().UseSqlite("Filename=RideTest.db")
            .Options)
        {
            _context = new AppDbContext(ContextOptions);
            _rideService = new RideService(_context);
        }

        [Fact]
        public void GetAllRides_Test()
        {
            // Arrange & Act
            var rides = _rideService.GetAllRides();

            // Assert
            Assert.Equal(2, rides.Count());
        }


    }
}
