using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using UserManagementTestApp.Models;
using Xunit;
using ZPool.Models;

namespace xUnitTestProject
{
    public class ServiceTest
    {
        // This class:
        // Creation of ContextOptions
        // Seeding database with test data 

        protected DbContextOptions<AppDbContext> ContextOptions { get; }

        public ServiceTest(DbContextOptions<AppDbContext> contextOptions)
        {
            ContextOptions = contextOptions;
            Seed();
            
        }

        private void Seed()
        {
            // Here the test data is seeded to the test database.
            // You can add more data, but you have to attend to referential integrity, else exception.
            // If new data is added, it might change the outcome of previous tests (e.g. Count() of items in a list)

            using (var context = new AppDbContext(ContextOptions))
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();


                #region List of Users
                
                context.Users.Add(new AppUser()
                {
                    Id = 1,
                    Email = "user@email.com",
                    FirstName = "Tester",
                    LastName = "Master",
                    UserName = "TestMaster"
                });
                context.Users.Add(new AppUser()
                {
                    Id = 2,
                    Email = "user2@email.com",
                    FirstName = "Another",
                    LastName = "Tester",
                    UserName = "TesterNo2"
                });
                #endregion


                #region List of Cars

                context.Cars.Add(new Car()
                {
                    CarID = 1,
                    AppUserID = 1,
                    Brand = "Skoda",
                    Model = "CityGo",
                    Color = "red",
                    NumberOfSeats = 5,
                    NumberPlate = "AB12345"
                });

                context.Cars.Add(new Car()
                {
                    CarID = 2,
                    AppUserID = 1,
                    Brand = "Volvo",
                    Model = "S60",
                    Color = "gray",
                    NumberOfSeats = 5,
                    NumberPlate = "XY12345"
                });

                context.Cars.Add(new Car()
                {
                    CarID = 3,
                    AppUserID = 2,
                    Brand = "Peugeot",
                    Model = "206",
                    Color = "black",
                    NumberOfSeats = 5,
                    NumberPlate = "CD12345"
                });


                #endregion


                #region List of Rides

                context.Rides.Add(new Ride()
                {
                    RideID = 1,
                    CarID = 1,
                    DepartureLocation = "Copenhagen",
                    DestinationLocation = "Roskilde",
                    StartTime = DateTime.Now,
                    SeatsAvailable = 3
                });

                context.Rides.Add(new Ride()
                {
                    RideID = 2,
                    CarID = 2,
                    DepartureLocation = "Slagelse",
                    DestinationLocation = "Roskilde",
                    StartTime = DateTime.Now,
                    SeatsAvailable = 3
                });

                #endregion
                

                context.SaveChanges();
            }
        }

    }
}
